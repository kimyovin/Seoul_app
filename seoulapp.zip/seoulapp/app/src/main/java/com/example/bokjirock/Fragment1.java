package com.example.bokjirock;


import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class Fragment1 extends Fragment {

    String queryUrl = "http://www.bokjiro.go.kr/openapi/rest/gvmtWelSvc?crtiKey=uBDRiqRLBoeq9U0S3l2DfIA11tHI2iHGlBuLi722hUi0T8WZ9IUpYwxrE0VFf78meUlyC8ymW9ROB%2FDXmlokrQ%3D%3D&callTp=L&pageNum=1&numOfRows=500";
    String a = "a";
    String b = "b";
    AssetManager assetManager;

    public static Fragment1 newInstance() {
        Fragment1 fragment = new Fragment1();
        return fragment;
    }

}