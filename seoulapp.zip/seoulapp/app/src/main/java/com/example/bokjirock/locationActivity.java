package com.example.bokjirock;

public class locationActivity {
}
