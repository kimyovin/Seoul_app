package com.example.bokjirock;

import androidx.fragment.app.Fragment;

public class Fragment2 extends Fragment{
    public static Fragment1 newInstance(){
        Fragment1 fragment = new Fragment1();
        return fragment;
    }
}
